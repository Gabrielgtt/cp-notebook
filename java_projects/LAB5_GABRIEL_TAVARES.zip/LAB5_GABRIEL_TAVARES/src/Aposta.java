/**
 * Representação de uma aposta. 
 * Armazena o cenário, nome do apostador, o valor e a previsão e tem sua específica representação textual.
 * @author Gabriel Alves Tavares
 */
public class Aposta {
	
	private String apostador;
	private int valor;
	private String previsao;

	/**
	 * Construtor de aposta que atribui seus atributos conforme recebido.
	 * @param apostador nome do apostador.
	 * @param valor valor da aposta (em centavos).
	 * @param previsao "VAI ACONTECER" ou "N VAI ACONTECER".
 	 * @param tipo string usada para especificar a mensagem de erro. 
	 * Pode ser "aposta", "aposta assegurada por valor" ou "aposta assegurada por taxa".
	 */
	public Aposta(String apostador, int valor, String previsao, String tipo) {
		this.validarCadastroAposta(apostador, valor, previsao, tipo);
		this.apostador = apostador;
		this.valor = valor;
		this.previsao = previsao;
	}
	
	/**
	 * Validador dos argumentos da criação de apostas.
	 * @param apostador nome do apostador.
	 * @param valor valor da aposta (em centavos).
	 * @param previsao "VAI ACONTECER" ou "N VAI ACONTECER". 
	 * @param tipoAposta string usada para especificar a mensagem de erro. 
	 * Pode ser "aposta", "aposta assegurada por valor" ou "aposta assegurada por taxa".
	 */
	private void validarCadastroAposta(String apostador, int valor, String previsao, String tipoAposta) {
		if (apostador == null || apostador.trim().equals("")) {
			throw new IllegalArgumentException(("Erro no cadastro de " + tipoAposta + ": Apostador nao pode ser vazio ou nulo"));
		}
		if (valor <= 0) {
			throw new IllegalArgumentException("Erro no cadastro de " + tipoAposta + ": Valor nao pode ser menor ou igual a zero");
		}
		if (previsao == null || previsao.trim().equals("")) {
			throw new IllegalArgumentException("Erro no cadastro de " + tipoAposta + ": Previsao nao pode ser vazia ou nula");
		}
		if (!previsao.equals("VAI ACONTECER") && !previsao.equals("N VAI ACONTECER")) {
			throw new IllegalArgumentException("Erro no cadastro de " + tipoAposta + ": Previsao invalida");
		}
	}

	/**
	 * @return valor da aposta.
	 */
	public int getValor() {
		return this.valor;
	}

	/**
	 * @return se a previsão é de que o cenário ocorrerá.
	 */
	public boolean getPrevisao() {
		return this.previsao.equals("VAI ACONTECER");
	}
	
	/**
	 * @return representação textual da aposta com nome do apostador, valor em Reais e a previsão.
	 */
	public String toString() {
		double valorReais = ((double) valor) / (double) 100;
		return String.format("%s - R$%.2f - %s", this.apostador, valorReais, this.previsao);
	}
}
