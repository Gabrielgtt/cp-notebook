/**
 * Representação de um cenário com bônus. O bônus é um valor adicionado inicialmente ao caixa do cenário,
 * retirado do caixa do sistema.
 * @author Gabriel Alves Tavares	
 *
 */
public class CenarioComBonus extends Cenario {
		
		private int bonus;
			
		/**
		 * Constrói um cenário adicionando o bônus ao rateio total.
		 * @param descricao descrição do cenário.
		 * @param numeracao número do cenário.
		 * @param bonus valor bônus a ser destribuido para o vencedores das apostas desse cenário. 
		 */
		public CenarioComBonus(String descricao, int numeracao, int bonus) {
			super(descricao, numeracao);
			this.bonus = bonus;
			this.totalRateio = bonus;
		}
		
		/**
		 * Representação em string do cenário com o bônus.
		 */
		@Override
		public String toString() {
			return String.format("%s - R$ %.2f", super.toString(), (double) this.bonus/100);
		}
}

