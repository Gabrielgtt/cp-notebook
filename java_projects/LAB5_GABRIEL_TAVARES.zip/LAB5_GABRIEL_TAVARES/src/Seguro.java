/**
 * Represantação de um seguro de umas aposta. Calcula o valor assegurada durante sua construção e é usada como parte
 * da representação textual e uma aposta assegurada.
 * @author Gabriel Alves Tavares
 */
public class Seguro {

	private int valorAssegurado;
	private String toString;
	
	/**
	 * Construtor de seguro que recebe o valor assegurada.
	 * Cria uma representação textual para o seguro.
	 * @param valorSeguro valor assegurado ao apostador.
	 */
	public Seguro(int valorSeguro){
		this.valorAssegurado = valorSeguro;
		this.toString = String.format("(VALOR) - %d", valorSeguro);
	}
	
	/**
	 * Construtor de seguro que recebe a taxa e o valor da aposta e calcula o valor assegurado.
	 * Cria uma representação textual para o seguro.
	 * @param valorAposta valor da aposta a qual esse seguro pertence.
	 * @param taxa taxa usada para calcular quanto da aposta será assegurado.
	 */
	public Seguro(int valorAposta, double taxa){
		this.valorAssegurado = (int) (valorAposta * taxa);
		this.toString = String.format("(TAXA) - %.0f%%", taxa*100);
	}
	
	/**
	 * @return valor assegurado.
	 */
	public int getValorSeguro() {
		return this.valorAssegurado;
	}
	
	/**
	 * @return representação textual do seguro.
	 */
	public String toString() {
		return this.toString;
	}
}
