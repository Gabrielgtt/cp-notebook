/**
 * Classe que controla o armazenamento e retorno de informações sobre as apostas.
 * Possui dois Maps para armazenar as apostas mapeando-as conforme os cenários correspondentes.
 * @author Gabriel Alves Tavares
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
public class ControleApostas {

	private Map <Integer, ArrayList <Aposta>> apostas;
	private Map <Integer, ArrayList <ApostaAssegurada>> apostasAsseguradas;
	
	/**
	 * Construtor de apostas que inicializa os HashMaps de apostas normais e asseguradas.
	 */
	public ControleApostas() {
		this.apostas = new HashMap <Integer, ArrayList <Aposta>>();
		this.apostasAsseguradas = new HashMap <Integer, ArrayList <ApostaAssegurada>>();
	}
	
	/**
	 * Cadastra um novo cenário no Map que relaciona um cenário à suas apostas.
	 * @param cenario número do cenário.
	 */
	public void cadastrarCenario(int cenario) {
		this.apostas.put(cenario, new ArrayList<Aposta>());
		this.apostasAsseguradas.put(cenario, new ArrayList<ApostaAssegurada>());
	}
	
	/**
	 * Constrói e adiciona uma aposta ao ArrayList de apostas.
	 * @param cenario número de cenário.
	 * @param apostador nome do apostador.
	 * @param valor valor da aposta (em centavos).
	 * @param previsao "VAI ACONTECER" ou "N VAI ACONTECER".
	 */
	public void cadastrarAposta(int cenario, String apostador, int valor, String previsao) {
		Aposta aposta = new Aposta(apostador, valor, previsao, "aposta");
		this.apostas.get(cenario).add(aposta);
	}

	/**
	 * Constrói e adiciona uma aposta assegurada por valor ao ArrayList de apostas.
	 * @param cenario número de cenário.
	 * @param apostador nome do apostador.
	 * @param valor valor da aposta (em centavos).
	 * @param previsao "VAI ACONTECER" ou "N VAI ACONTECER".
	 * @param valorSeguro valor que o apostador receberá caso perca a aposta, descontando do banco do sistema.
	 * @return a numeração da aposta segura que será usada pra indentifica-la futuramente.
	 */
	public int cadastrarApostaSeguraValor(int cenario, String apostador, int valor, String previsao, int valorSeguro) {
		ApostaAssegurada aposta = new ApostaAssegurada(apostador, valor, previsao, valorSeguro);
		this.apostas.get(cenario).add(aposta);
		this.apostasAsseguradas.get(cenario).add(aposta);
		return apostasAsseguradas.get(cenario).size() - 1;
	}
	
	/**
	 * Constrói e adiciona uma aposta assegurada por valor ao ArrayList de apostas.
	 * @param cenario número de cenário.
	 * @param apostador nome do apostador.
	 * @param valor valor da aposta (em centavos).
	 * @param previsao "VAI ACONTECER" ou "N VAI ACONTECER".
	 * @param taxa taxa da aposta que será segurada para o apostador caso perca.
	 * @return a numeração da aposta segura que será usada pra indentifica-la futuramente.
	 */	
	public int cadastrarApostaSeguraTaxa(int cenario, String apostador, int valor, String previsao, double taxa) {
		ApostaAssegurada aposta = new ApostaAssegurada(apostador, valor, previsao, taxa);
		this.apostas.get(cenario).add(aposta);
		this.apostasAsseguradas.get(cenario).add(aposta);		
		return apostasAsseguradas.get(cenario).size() - 1;
	}

	/**
	 * Soma o valor de todas as apostas em um cenário.
	 * @param cenario número de cenário.
	 * @return soma de todas as apostas do cenário especificado.
	 */
	public int valorTotalDeApostas(int cenario) {
		int valorTotal = 0;
		for (Aposta aposta : this.apostas.get(cenario)) {
			valorTotal += aposta.getValor();				
		}
		return valorTotal;
	}

	/**
	 * Soma o valor total assegurado pelos apostadores ao fechar um cenário.
	 * @param cenario número do cenário a qual pertence a aposta.
	 * @param ocorreu booleano que indica se ocorreu (True) ou não (False) a previsão
	 * @return o valor total de seguros que serão usados ao fechar essa aposta, ou seja, 
	 * a soma dos seguros das apostas erradas.
	 */
	public int valorSeguros(int cenario, boolean ocorreu) {
		int totalSeguro = 0;
		
		for (ApostaAssegurada aposta : this.apostasAsseguradas.get(cenario)) {
			if (aposta.getPrevisao() != ocorreu) {
				totalSeguro += aposta.getValorSeguro();
			}
		}
		return totalSeguro;
	}
	
	/**
	 * Retorna o número de apostas que um cenário recebeu.
	 * @param cenario número do cenário a qual pertence a aposta.
	 * @return número de apostas que o cenário especificado recebeu.
	 */
	public int totalDeApostas(int cenario) {
		return this.apostas.get(cenario).size();
	}

	/**
	 * Cria e retona uma lista com todas as representações textuais de todas as apostas de um cenário.
	 * @param cenario número do cenário a qual pertence a aposta.
	 * @return todos os toString das apostas de um cenários (um por linha).
	 */
	public String exibeApostas(int cenario) {
		String listaApostas = "";
		for (Aposta aposta : this.apostas.get(cenario)) {
			listaApostas += aposta.toString() + System.lineSeparator();
		}
		return listaApostas;
	}

	/**
	 * Retorna a soma do valor de todas as apostas erradas.
	 * @param cenario número do cenário a qual pertence a aposta.
	 * @param ocorreu ocorrência do cenário (true ou false).
	 * @return soma do valor de todas apostas de previsão errada.
	 */
	public int valorApostasErradas(int cenario, boolean ocorreu) {
		int valorErradas = 0;
		for (Aposta aposta : this.apostas.get(cenario)) {
			if (aposta.getPrevisao() != ocorreu) {
				valorErradas += aposta.getValor();
			}
		}
		return valorErradas;
	}

	/**
	 * Altera o tipo de seguro de umas aposta assegurada para o tipo seguroValor.
	 * @param cenario número do cenário a qual pertence a aposta
	 * @param apostaAssegurada index da apostaAssegurada.
	 * @param valor valor do novo seguro.
	 */
	public void alterarSeguroValor(int cenario, int apostaAssegurada, int valor) {
		this.apostasAsseguradas.get(cenario).get(apostaAssegurada).setSeguro(valor);
	}


	/**
	 * Altera o tipo de seguro de umas aposta assegurada para o tipo seguroTaxa.
	 * @param cenario número do cenário a qual pertence a aposta
	 * @param apostaAssegurada index da apostaAssegurada.
	 * @param taxa taxa do novo seguro.
	 */
	public void alterarSeguroTaxa(int cenario, int apostaAssegurada, double taxa) {
		this.apostasAsseguradas.get(cenario).get(apostaAssegurada).setSeguro(taxa);		
	}
	
}
