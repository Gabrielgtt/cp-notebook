/**
 * Sub-classe de aposta que armazena um seguro usado caso a previsão esteja errada.
 * @author Gabriel Alves Tavares
 *
 */
public class ApostaAssegurada extends Aposta {
	
	private Seguro seguro;

	/**
	 * Construtor da apostaAssegurada por valor que usa da classe mãe para validação e atribuição de argumentos.
	 * @param apostador nome do apostador.
	 * @param valor valor da aposta (em centavos).
	 * @param previsao "VAI ACONTECER" ou "N VAI ACONTECER".
	 * @param valorSeguro valor assegurado ao apostador.
	 */
	public ApostaAssegurada(String apostador, int valor, String previsao, int valorSeguro) {
		super(apostador, valor, previsao, "aposta assegurada por valor");
		setSeguro(valorSeguro);
	}

	/**
	 * Construtor da apostaAssegurada por taxa que usa da classe mãe para validação e atribuição de argumentos.
	 * @param apostador nome do apostador.
	 * @param valor valor da aposta (em centavos).
	 * @param previsao "VAI ACONTECER" ou "N VAI ACONTECER".
	 * @param taxa porcentam da aposta que será assegurada ao apostador.
	 */
	public ApostaAssegurada(String apostador, int valor, String previsao, double taxa) {
		super(apostador, valor, previsao, "aposta assegurada por taxa");
		setSeguro(taxa);
	}
	
	/**
	 * Modifica o seguro dessa aposta para um do tipo Valor.
	 * @param valorSeguro valor assegurado pelo apostador caso perca a aposta.
	 */
	public void setSeguro(int valorSeguro) {
		this.seguro = new Seguro(valorSeguro);
	}
	
	/**
	 * Modifica o seguro dessa aposta para um do tipo Taxa.
	 * @param taxa taxa da aposta que será segurada para o apostador caso perca.
	 */
	public void setSeguro(double taxa) {
		this.seguro = new Seguro(super.getValor(), taxa);
	}
	
	/**
	 * @return valor do seguro da aposta.
	 */
	public int getValorSeguro() {
		return this.seguro.getValorSeguro();
	}
	
	/**
	 * @return representação textual da aposta com nome do apostador, valor em Reais e a previsão.
	 */
	@Override
	public String toString() {
		return String.format("%s - ASSEGURADA %s",  super.toString(), seguro.toString());
	}
	
	
}
