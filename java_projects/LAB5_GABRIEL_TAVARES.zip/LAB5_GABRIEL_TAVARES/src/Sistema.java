/**
 * Classe de controle principal. 
 * Comanda o controlador de cenários e o controlador de apostas e as interações entre eles.
 * @author Gabriel Alves Tavares
 */
public class Sistema {

	private int caixa;
	private double taxa;
	private ControleCenarios ctrlCenarios;
	private ControleApostas ctrlApostas;
	
	/**
	 * Construtor do sistema que inicializa os controles de cenários e apostas tal como recebe.
	 * o valor inicial do caixa e a taxa de lucro sobre as apostas erradas.
	 * @param caixa valor inicial do caixa (em centavos).
	 * @param taxa valor da taxa de lucro sobre as apostas erradas.
	 */
	public Sistema(int caixa, double taxa) {
		if (caixa < 0) {
			throw new IllegalArgumentException("Erro na inicializacao: Caixa nao pode ser inferior a 0");
		}
		if (taxa < 0.0) {
			throw new IllegalArgumentException("Erro na inicializacao: Taxa nao pode ser inferior a 0");
		}
		this.ctrlCenarios = new ControleCenarios();
		this.ctrlApostas = new ControleApostas();
		this.caixa = caixa;
		this.taxa = taxa;
	}

	/**
	 * @return caixa do sistema.
	 */
	public int getCaixa() {
		return this.caixa;
	}

	/**
	 * Cadastra um cenário e retorna a numeração do cenário.
	 * @param descricao descrição textual do cenário.
	 * @return numeração do cenário.
	 */
	public int cadastrarCenario(String descricao) {
		int numCenario = this.ctrlCenarios.cadastrarCenario(descricao);
		this.ctrlApostas.cadastrarCenario(numCenario);
		return numCenario;
	}

	/**
	 * Cadastra um cenário com bônus.
	 * @param descricao descrição textual do cenário.
	 * @param bonus valor bônus a ser destribuido para o vencedores das apostas desse cenário.
	 * @return numeração do cenário.
	 */
	public int cadastrarCenario(String descricao, int bonus) {
		if (caixa < bonus || bonus == 0) {
			throw new IllegalArgumentException("Erro no cadastro de cenario: Bonus invalido");
		}
		this.caixa -= bonus;
		int numCenario = this.ctrlCenarios.cadastrarCenario(descricao, bonus);
		this.ctrlApostas.cadastrarCenario(numCenario);
		return numCenario;
	}

	/**
	 * Exibe a representação textual de um cenário.
	 * @param cenario número do cenário.
	 * @return toString do cenário escolhido.
	 */
	public String exibirCenario(int cenario) {
		return this.ctrlCenarios.exibirCenario(cenario);
	}

	/**
	 * @return uma lista com a representação textual de todos os cenários em ordem de cadastro.
	 */
	public String exibirCenarios() {
		return this.ctrlCenarios.exibirCenarios();
	}

	/**
	 * Cadastra uma nova aposta.
	 * @param cenario número do cenário.
	 * @param apostador nome do apostador.
	 * @param valor valor da aposta (em centavos).
	 * @param previsao "VAI ACONTECER" ou "N VAI ACONTECER".
	 */
	public void cadastrarAposta(int cenario, String apostador, int valor, String previsao) {
		validarCenario(cenario, "Erro no cadastro de aposta", true);
		this.ctrlApostas.cadastrarAposta(cenario, apostador, valor, previsao);
		this.ctrlCenarios.addAposta(cenario);
	}


	/**
	 * Cadastra uma nova aposta assegurada por valor.
	 * @param cenario número do cenário.
	 * @param apostador nome do apostador.
	 * @param valor valor da aposta (em centavos).
	 * @param previsao "VAI ACONTECER" ou "N VAI ACONTECER".
	 * @param valorSeguro valor que o apostador receberá caso perca a aposta.
	 * @param custoSeguro valor pago pelo apostador pelo seguro.
	 * @return a numeração da aposta segura que será usada pra indentifica-la futuramente.
	 */
	public int cadastrarApostaSeguraValor(int cenario, String apostador, int valor, String previsao, int valorSeguro, int custoSeguro) {
		validarCenario(cenario, "Erro no cadastro de aposta assegurada por valor", true);
		this.caixa += custoSeguro;
		int idAposta = this.ctrlApostas.cadastrarApostaSeguraValor(cenario, apostador, valor, previsao, valorSeguro);
		this.ctrlCenarios.addAposta(cenario);
		return idAposta;
	}

	/**
	 * Cadastra uma nova aposta assegurada por valor.
	 * @param cenario número do cenário.
	 * @param apostador nome do apostador.
	 * @param valor valor da aposta (em centavos).
	 * @param previsao "VAI ACONTECER" ou "N VAI ACONTECER".
	 * @param taxa taxa da aposta que será segurada para o apostador caso perca.
	 * @param custoSeguro valor pago pelo apostador pelo seguro.
	 * @return a numeração da aposta segura que será usada pra indentifica-la futuramente.
	 */
	public int cadastrarApostaSeguraTaxa(int cenario, String apostador, int valor, String previsao, double taxa, int custoSeguro) {
		validarCenario(cenario, "Erro no cadastro de aposta assegurada por taxa", true);
		this.caixa += custoSeguro;
		int idAposta = this.ctrlApostas.cadastrarApostaSeguraTaxa(cenario, apostador, valor, previsao, taxa);
		this.ctrlCenarios.addAposta(cenario);
		return idAposta;
	}
	
	/**
	 * Obtém o valor total apostado em um cenário.
	 * @param cenario número do cenário.
	 * @return soma do valor de todas as apostas feitas em um cenário.
	 */
	public int valorTotalDeApostas(int cenario) {
		validarCenario(cenario, "Erro na consulta do valor total de apostas", true);
		return this.ctrlApostas.valorTotalDeApostas(cenario);
	}

	/**
	 * Obtém o número de apostas feitas em um cenário.
	 * @param cenario número do cenário.
	 * @return número de apostas feitas em um cenário.
	 */
	public int totalDeApostas(int cenario) {
		validarCenario(cenario, "Erro na consulta do total de apostas", true);
		return this.ctrlApostas.totalDeApostas(cenario);
	}
	
	/**
	 * Exibe todas as apostas de um cenário.
	 * @param cenario número do cenário.
	 * @return toString de todas as apostas (uma por linha).
	 */
	public String exibeApostas(int cenario) {
		return this.ctrlApostas.exibeApostas(cenario);
	}

	/**
	 * Valdiador de cenário que garante que o cenário acessado existe e que a operação desejada
	 * não é feita quando o cenário deveria estar fechado, ou do contrário, quando deveria estar aberto.
	 * @param cenario número do cenário.
	 * @param mensagemDeErro mensagem que indica qual é a mensagem de erro se ouver invalidez.
	 * @param aberto indica como deveria estar o cenário para a ação ser considerada válida: True se aberto, False se fechado.
	 */
	private void validarCenario(int cenario, String mensagemDeErro, boolean aberto) {
		if (cenario <= 0) {
			throw new IllegalArgumentException(mensagemDeErro + ": Cenario invalido");
		}
		if (cenario > ctrlCenarios.numeroDeCenarios()) {
			throw new IllegalArgumentException(mensagemDeErro + ": Cenario nao cadastrado");
		}
		if (aberto) {
			if (ctrlCenarios.fechado(cenario)) {
				throw new IllegalArgumentException(mensagemDeErro + ": Cenario ja esta fechado");
			}
		} else {
			if (!ctrlCenarios.fechado(cenario)) {
				throw new IllegalArgumentException(mensagemDeErro + ": Cenario ainda esta aberto");
			}
		}
	}
	
	/**
	 * Encerra um cenário (indicando se ocorreu ou não).
	 * Adiciona ao caixa do sistema a multiplicação entre a taxa e a soma de todas as apostas erradas.
	 * para o cenário fechado e salva no cenário esse valor e o rateio total.
	 * @param cenario número do cenário.
	 * @param ocorreu booleando que indica a ocorrência do cenário.
	 */
	public void fecharAposta(int cenario, boolean ocorreu) {
		validarCenario(cenario, "Erro ao fechar aposta", true);
		
		int valorApostasErradas = this.ctrlApostas.valorApostasErradas(cenario, ocorreu);
		int valorTaxado = (int) Math.floor(((double) valorApostasErradas * taxa));
		int totalRateio = (valorApostasErradas - valorTaxado);
		
		this.caixa += valorTaxado;
		this.caixa -= ctrlApostas.valorSeguros(cenario, ocorreu);
		
		this.ctrlCenarios.fecharCenario(cenario, ocorreu, valorTaxado, totalRateio);
	}

	/**
	 * Obtém o valor total de um cenário encerrado que será destinado ao caixa.
	 * @param cenario número do cenário.
	 * @return o valor total de um cenário encerrado que será destinado ao caixa.
	 */
	public int getCaixaCenario(int cenario) {
		validarCenario(cenario, "Erro na consulta do caixa do cenario", false);
		return this.ctrlCenarios.getCaixaCenario(cenario);
	}

	/**
	 * Obtém o valor total de um cenário encerrado que será destinado a distribuição entre as apostas vencedoras.
	 * @param cenario número do cenário.
	 * @return o valor total de um cenário encerrado que será destinado a distribuição entre as apostas vencedoras.
	 */
	public int getTotalRateioCenario(int cenario) {
		validarCenario(cenario, "Erro na consulta do total de rateio do cenario", false);
		return this.ctrlCenarios.getTotalRateio(cenario);
	}

	/**
	 * Altera o tipo de seguro da aposta para um do tipo Valor.
	 * @param cenario número do cenário. 
	 * @param apostaAssegurada numeração da aposta assegurada.
	 * @param valor valor assegurado
	 */
	public void alterarSeguroValor(int cenario, int apostaAssegurada, int valor) {
		this.ctrlApostas.alterarSeguroValor(cenario, apostaAssegurada, valor);
	}

	/**
	 * Altera o tipo de seguro da aposta para um do tipo Valor.
	 * @param cenario número do cenário. 
	 * @param apostaAssegurada numeração da aposta assegurada.
	 * @param taxa porcentagem do valor da aposta que está assegurado ao apostador.
	 */
	public void alterarSeguroTaxa(int cenario, int apostaAssegurada, double taxa) {
		this.ctrlApostas.alterarSeguroTaxa(cenario, apostaAssegurada, taxa);
	}

	/**
	 * Ordena os cenários por um tipo específico de comparação. 
	 * Três tipos de comparação foram definidos: por cadastro, nome e número de apostas.
	 * @param ordem string com o nome da ordenação
	 */
	public void alterarOrdem(String ordem) {
		this.ctrlCenarios.alterarOrdem(ordem);
	}

	/**
	 * Exibe um cenário na ordem especificada anteriormente.
	 * @param cenario posição do cenário na ordem especificada anteriormente.
	 * @return toString do cenário desejado.
	 */
	public String exibirCenarioOrdenado(int cenario) {
		return this.ctrlCenarios.exibirCenarioOrdenado(cenario);
	}

}
