
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class ApostaTest {

	private Aposta aposta1;
	private Aposta aposta2;
	private Aposta aposta3;
	private Aposta aposta4;
	
	@Before
	public void inicializar() {
		double taxa = 0.5;
		int valorSeguro = 200;
		this.aposta1 = new Aposta("Gabriel", 100, "VAI ACONTECER", "aposta");	
		this.aposta2 = new Aposta("Matheus", 12345, "N VAI ACONTECER", "aposta");
		this.aposta3 = new ApostaAssegurada("Matheus", 1234, "N VAI ACONTECER", taxa);
		this.aposta4 = new ApostaAssegurada("Matheus", 12355, "N VAI ACONTECER", valorSeguro);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void ValorZerado() {
		Aposta aposta = new Aposta("Tai", 0, "VAI ACONTECER", "aposta");
		fail("Aposta craida com valor = 0");
	}

	@Test(expected=IllegalArgumentException.class)
	public void ApostadorNulo() {
		Aposta aposta = new Aposta(null, 100, "VAI ACONTECER", "aposta");
		fail("Aposta criado com nome do apostador nulo");
	}

	@Test(expected=IllegalArgumentException.class)
	public void ApostadorVazio() {
		Aposta aposta = new Aposta("   ", 0, "VAI ACONTECER", "aposta");
		fail("Aposta criado com nome do apostador vazio");
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void PrevisaoNula() {
		Aposta aposta = new Aposta("Tai", 100, null, "aposta");
		fail("Aposta criado com nome do previsao nula");
	}

	@Test(expected=IllegalArgumentException.class)
	public void PrevisaoVazia() {
		Aposta aposta = new Aposta("Tai", 0, "  ", "aposta");
		fail("Aposta criado com nome do previsao vazia");
	}


	@Test(expected=IllegalArgumentException.class)
	public void PrevisaoInvalida() {
		Aposta aposta = new Aposta("Tai", 0, "Vai dar bom", "aposta");
		fail("Aposta criado com nome do previsao invalida");
	}
	
	@Test
	public void getValorTest() {
		assertEquals(100, this.aposta1.getValor());
	}
	
	@Test
	public void getPrevisaoTest() {
		assertEquals(true, this.aposta1.getPrevisao());
	}
	
	@Test
	public void getToStringTest1() {
		assertEquals("Gabriel - R$1,00 - VAI ACONTECER", this.aposta1.toString());
	}
	
	@Test
	public void getToStringTest2() {
		assertEquals("Matheus - R$123,45 - N VAI ACONTECER", this.aposta2.toString());
	}

	@Test
	public void getToStringSeguroTaxa() {
		assertEquals("Matheus - R$12,34 - N VAI ACONTECER - ASSEGURADA (TAXA) - 50%", this.aposta3.toString());
	}
	
	@Test
	public void getToStringSeguroValor() {
		assertEquals("Matheus - R$123,55 - N VAI ACONTECER - ASSEGURADA (VALOR) - 200", this.aposta4.toString());
	}
}
