
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

public class CenarioTest {
	
	private Cenario cenario;
	private Cenario cenarioFechado1;
	private Cenario cenarioFechado2;

	@Before
	public void inicializar() {
		this.cenario = new Cenario ("Tirar 10 no Lab5", 1);
		
		this.cenarioFechado1 = new Cenario ("Tirar A+ no Lab5", 2);
		cenarioFechado1.fechar(true, 200, 100);
		
		this.cenarioFechado2 = new Cenario ("Tirar A+ no Lab5", 3);
		cenarioFechado2.fechar(false, 200, 100);
	}
	
	@Test
	public void toStringTest() {
		assertEquals("1 - Tirar 10 no Lab5 - Nao finalizado", this.cenario.toString());
	}

	@Test(expected=IllegalAccessError.class)
	public void getCaixaCenarioAberto() {
		cenario.getCaixa();
		fail("caixa de um cenário foi acessado sem ele ter sido finalizado");
	}
	
	@Test(expected=IllegalAccessError.class)
	public void getTotalRateioCenarioAberto() {
		cenario.getTotalRateio();
		fail("rateio de um cenário foi acessado sem ele ter sido finalizado");
	}
	
	@Test(expected=IllegalAccessError.class)
	public void fecharTestFechado() {
		cenarioFechado1.fechar(true, 100, 200);
	}

	@Test
	public void getCaixaCenarioFechado() {
		assertEquals(200, this.cenarioFechado1.getCaixa());
	}
	
	@Test
	public void getTotalRateioCenarioFechado() {
		assertEquals(100, this.cenarioFechado1.getTotalRateio());
	}
	
	
	@Test
	public void CenarioFechado1ToStringTest() {
		assertEquals("2 - Tirar A+ no Lab5 - Finalizado (ocorreu)", this.cenarioFechado1.toString());
	}
	
	@Test
	public void CenarioFechado2ToStringTest() {
		assertEquals("3 - Tirar A+ no Lab5 - Finalizado (n ocorreu)", this.cenarioFechado2.toString());
	}
	
	@Test
	public void CenarioBonusToStringTest() {
		CenarioComBonus cenario = new CenarioComBonus("Um teste", 1, 30);
		assertEquals("1 - Um teste - Nao finalizado - R$ 0,30", cenario.toString());
	}
			
}
