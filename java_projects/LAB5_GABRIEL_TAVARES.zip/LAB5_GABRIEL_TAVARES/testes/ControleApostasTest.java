import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class ControleApostasTest {

	private ControleApostas ctrlApostas;
	
	@Before
	public void inicializar() {
		this.ctrlApostas = new ControleApostas();
		this.ctrlApostas.cadastrarCenario(0);
		this.ctrlApostas.cadastrarAposta(0, "Gabriel", 100, "VAI ACONTECER");
		this.ctrlApostas.cadastrarApostaSeguraTaxa(0, "Matheus", 1000, "VAI ACONTECER", 0.5);
		this.ctrlApostas.cadastrarApostaSeguraValor(0, "Matheus", 120, "VAI ACONTECER", 200);
	}
	
	@Test
	public void exibeApostasTest() {
		String esperado = "Gabriel - R$1,00 - VAI ACONTECER" + System.lineSeparator() +
				"Matheus - R$10,00 - VAI ACONTECER - ASSEGURADA (TAXA) - 50%" + System.lineSeparator() +
				"Matheus - R$1,20 - VAI ACONTECER - ASSEGURADA (VALOR) - 200" + System.lineSeparator();
		assertEquals(esperado, this.ctrlApostas.exibeApostas(0));
	}
	
	@Test
	public void AlteraSeguroValorTest() {
		this.ctrlApostas.alterarSeguroValor(0, 0, 300); 
		String esperado = "Gabriel - R$1,00 - VAI ACONTECER" + System.lineSeparator() +
				"Matheus - R$10,00 - VAI ACONTECER - ASSEGURADA (VALOR) - 300" + System.lineSeparator() +
				"Matheus - R$1,20 - VAI ACONTECER - ASSEGURADA (VALOR) - 200" + System.lineSeparator();
		assertEquals(esperado, this.ctrlApostas.exibeApostas(0));
	}

	@Test
	public void AlteraSeguroTaxaTest() {
		this.ctrlApostas.alterarSeguroTaxa(0, 0, 0.65);
		this.ctrlApostas.alterarSeguroTaxa(0, 1, 0.30); 
		String esperado = "Gabriel - R$1,00 - VAI ACONTECER" + System.lineSeparator() +
				"Matheus - R$10,00 - VAI ACONTECER - ASSEGURADA (TAXA) - 65%" + System.lineSeparator() +
				"Matheus - R$1,20 - VAI ACONTECER - ASSEGURADA (TAXA) - 30%" + System.lineSeparator();
		assertEquals(esperado, this.ctrlApostas.exibeApostas(0));
	}

	@Test
	public void valorApostasErradasTest() {
		assertEquals(1220, this.ctrlApostas.valorApostasErradas(0, false));
	}
	
	@Test
	public void valorTotalApostasTest() {
		assertEquals(1220, this.ctrlApostas.valorTotalDeApostas(0));
	}
	
	@Test
	public void quantidadeApostasTest() {
		assertEquals(3, this.ctrlApostas.totalDeApostas(0));
	}
	
	
}
